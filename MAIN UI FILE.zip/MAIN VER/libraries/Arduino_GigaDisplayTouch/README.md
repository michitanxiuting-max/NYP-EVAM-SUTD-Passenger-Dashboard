# 👇 Library for Arduino Giga Display Shield Touch controller

The Arduino Giga Display Touch library manages the touch controller of the Giga Display Shield, capturing up to 5 concurrent touch points.

📖 For more information about this library please read the documentation [here](./docs/).